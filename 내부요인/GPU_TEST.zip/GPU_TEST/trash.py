import subprocess
import time

def run_nvidia_smi(command):
    subprocess.run(command, shell=True)

# 두 명령어 설정
command1 = "nvidia-smi -i 0 -lgc 1700,1700"
command2 = "nvidia-smi -i 0 -lgc 1100,1100"

# 주기 설정 (1.8Hz 주기 -> 주기 시간은 1 / 1.8초)
period = 1 / 1.8

# 무한 루프에서 교대로 명령어 실행
try:
    while True:
        run_nvidia_smi(command1)
        time.sleep(period)
        run_nvidia_smi(command2)
        time.sleep(period)
except KeyboardInterrupt:
    print("Program terminated by user")
