import PyPDF2

# Load the PDF file
file_path = r'C:\Users\win\Desktop\GPU_TEST\etc\Going_green_optimizing_GPUs_for_energy_efficiency_through_model-steered_auto-tuning.pdf'
pdf_file = open(file_path, 'rb')
pdf_reader = PyPDF2.PdfFileReader(pdf_file)

# Extract all text from the PDF
pdf_text = ""
for page_num in range(pdf_reader.numPages):
    page = pdf_reader.getPage(page_num)
    pdf_text += page.extract_text()

pdf_file.close()

# Save the extracted text to a new file for translation
extracted_text_path = '/mnt/data/extracted_text.txt'
with open(extracted_text_path, 'w', encoding='utf-8') as text_file:
    text_file.write(pdf_text)

extracted_text_path
