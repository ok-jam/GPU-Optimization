import matplotlib.pyplot as plt
import numpy as np

# Data
GPU_CLOCK = [
    210, 300, 405, 510, 600, 705, 810, 900, 
    1005, 1110, 1200, 1305, 1410, 1500, 1605, 
    1710, 1800, 1905, 1935
]

GFLOPS = [
    34.80, 43.15, 58.04, 72.48, 86.14, 99.34, 114.35, 
    129.86, 143.24, 157.56, 172.40, 187.40, 200.88, 
    212.80, 226.19, 244.45, 256.78, 269.37, 274.13
]

Power_Consumption = [
    0.38, 0.39, 0.40, 0.34, 0.29, 0.26, 0.23, 0.21, 
    0.20, 0.18, 0.17, 0.16, 0.16, 0.16, 0.16, 0.16, 
    0.17, 0.19, 0.19
]

# Plotting both graphs in one figure
plt.figure(figsize=(12, 6))

# Plot 1: GPU_CLOCK vs GFLOPS
plt.subplot(1, 2, 1)  # (rows, columns, index)
plt.plot(GPU_CLOCK, GFLOPS, marker='o', linestyle='-', color='b', label='GFLOPS')
plt.xlabel('GPU Clock (MHz)')
plt.ylabel('GFLOPS')
plt.title('GPU Clock vs GFLOPS')
plt.grid(True)
plt.legend()

# Plot 2: GPU_CLOCK vs Power Consumption
plt.subplot(1, 2, 2)  # (rows, columns, index)
plt.plot(GPU_CLOCK, Power_Consumption, marker='o', linestyle='-', color='r', label='Power Consumption')
plt.xlabel('GPU Clock (MHz)')
plt.ylabel('Power Consumption (W)')
plt.title('GPU Clock vs Power Consumption')
plt.grid(True)
plt.legend()

plt.tight_layout()  # Adjust subplot parameters to give specified padding
plt.show()
