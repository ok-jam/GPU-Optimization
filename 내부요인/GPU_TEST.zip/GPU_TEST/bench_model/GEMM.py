import subprocess
import time
import multiprocessing
import cupy as cp
from queue import Empty  # queue 모듈에서 Empty 예외를 가져옵니다

def gemm_benchmark_cupy(size, num_iterations, queue=None):
    # Initialize matrices A, B, and C with random values on the GPU
    A = cp.random.rand(size, size)
    B = cp.random.rand(size, size)
    C = cp.random.rand(size, size)
    
    alpha = 1.0
    beta = 1.0
    
    # Warm-up
    cp.dot(A, B, out=C)
    cp.cuda.Stream.null.synchronize()

    # Measure performance
    start_time = time.time()
    for _ in range(num_iterations):
        C = alpha * cp.dot(A, B) + beta * C
    cp.cuda.Stream.null.synchronize()
    end_time = time.time()

    elapsed_time = end_time - start_time
    flops = 2 * size ** 3 * num_iterations  # 2 * n^3 operations per iteration
    gflops = (flops / elapsed_time) / 1e9

    print(f"Size: {size}, Time: {elapsed_time:.6f} seconds, GFLOPS: {gflops:.2f}")

    if queue:
        queue.put((elapsed_time, gflops))

def measure_power(queue, interval):
    try:
        start_time = time.time()
        while True:
            result = subprocess.run(['nvidia-smi', '--query-gpu=power.draw', '--format=csv,noheader'], capture_output=True, text=True)
            power_str = result.stdout.strip()  # 전체 문자열을 얻음 (예: '17.09 W')
            power_draw = float(power_str.split()[0])  # 공백을 기준으로 분할 후 첫 번째 요소를 숫자로 변환
            timestamp = time.time() - start_time
            queue.put((timestamp, power_draw))
            time.sleep(interval)
    except Exception as e:
        print(f"Error in power measurement process: {e}")

if __name__ == "__main__":
    interval = 0.1  # 측정 간격 (초)

    # 데이터를 공유할 큐 생성
    queue = multiprocessing.Queue()

    # 전력 측정 프로세스 시작
    power_process = multiprocessing.Process(target=measure_power, args=(queue, interval))
    power_process.start()

    try:
        # 벤치마크 실행 (여기서는 예시로 대기)
        gemm_benchmark_cupy(2048,2048)
    except KeyboardInterrupt:
        # 사용자가 Ctrl+C로 인터럽트한 경우 프로세스 종료
        pass

    # 전력 측정 프로세스 종료
    power_process.terminate()
    power_process.join()

    # 측정된 전력 소비량 처리
    total_energy = 0.0
    total_time = 0.0

    while True:
        try:
            timestamp, power_draw = queue.get_nowait()
            if timestamp > total_time:
                total_energy += power_draw * (timestamp - total_time)
                total_time = timestamp
        except Empty:
            break

    total_power_consumption = total_energy / 3600.0  # 에너지를 시간으로 나누어 소비전력으로 변환

    print(f"Total power consumption during benchmark: {total_power_consumption:.2f} W")