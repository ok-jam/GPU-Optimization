import tensorflow as tf
from tensorflow.keras.datasets import cifar100
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Flatten, GlobalAveragePooling2D
from tensorflow.keras.optimizers import Adam

# 데이터셋 로드 및 전처리
(x_train, y_train), (x_test, y_test) = cifar100.load_data()
y_train = to_categorical(y_train, 100)
y_test = to_categorical(y_test, 100)

# ResNet50 모델 불러오기 (ImageNet 가중치 사용, 탑 네트워크 제외)
base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(32, 32, 3))

# 커스텀 최상위 레이어 추가
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Flatten()(x)
x = Dense(1024, activation='relu')(x)
predictions = Dense(100, activation='softmax')(x)

# 모델 정의
model = Model(inputs=base_model.input, outputs=predictions)

# 모든 레이어 학습 가능 설정 (transfer learning을 위해 base_model의 레이어를 고정하려면 여기를 수정)
for layer in base_model.layers:
    layer.trainable = True

# 모델 컴파일
model.compile(optimizer=Adam(lr=0.0001), loss='categorical_crossentropy', metrics=['accuracy'])

# 모델 훈련
model.fit(x_train, y_train, batch_size=64, epochs=10, validation_data=(x_test, y_test))
