"""
------------------------------
아래는 이미지 분류 Deep Learning
------------------------------
"""

import numpy as np
import os
from sklearn.metrics import confusion_matrix
import seaborn as sn; sn.set(font_scale=1.4)
from sklearn.utils import shuffle           
import matplotlib.pyplot as plt             
import cv2                                 
import tensorflow as tf                
from tqdm import tqdm

import subprocess
import time
import multiprocessing
import cupy as cp
from queue import Empty  # queue 모듈에서 Empty 예외를 가져옵니다

start_time = time.time()

class_names = ['mountain', 'street', 'glacier', 'buildings', 'sea', 'forest']
class_names_label = {class_name:i for i, class_name in enumerate(class_names)}

nb_classes = len(class_names)

IMAGE_SIZE = (150, 150)

def load_data():
    """
        Load the data:
            - 14,034 images to train the network.
            - 3,000 images to evaluate how accurately the network learned to classify images.
    """
    
    datasets = [r'C:\Users\win\Desktop\GPU_TEST\seg_test', r'C:\Users\win\Desktop\GPU_TEST\seg_test']
    output = []
    
    # Iterate through training and test sets
    for dataset in datasets:
        
        images = []
        labels = []
        
        print("Loading {}".format(dataset))
        
        # Iterate through each folder corresponding to a category
        for folder in os.listdir(dataset):
            label = class_names_label[folder]
            
            # Iterate through each image in our folder
            for file in tqdm(os.listdir(os.path.join(dataset, folder))):
                
                # Get the path name of the image
                img_path = os.path.join(os.path.join(dataset, folder), file)
                
                # Open and resize the img
                image = cv2.imread(img_path)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                image = cv2.resize(image, IMAGE_SIZE) 
                
                # Append the image and its corresponding label to the output
                images.append(image)
                labels.append(label)
                
        images = np.array(images, dtype = 'float32')
        labels = np.array(labels, dtype = 'int32')   
        
        output.append((images, labels))

    return output

(train_images, train_labels), (test_images, test_labels) = load_data()

train_images, train_labels = shuffle(train_images, train_labels, random_state=25)

train_images = train_images / 255.0 
test_images = test_images / 255.0

model = tf.keras.Sequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation = 'relu', input_shape = (150, 150, 3)), 
    tf.keras.layers.MaxPooling2D(2,2),
    tf.keras.layers.Conv2D(32, (3, 3), activation = 'relu'),
    tf.keras.layers.MaxPooling2D(2,2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(128, activation=tf.nn.relu),
    tf.keras.layers.Dense(6, activation=tf.nn.softmax)
])

model.compile(optimizer = 'adam', loss = 'sparse_categorical_crossentropy', metrics=['accuracy'])


def measure_power(queue, interval):
    try:
        start_time = time.time()
        while True:
            result = subprocess.run(['nvidia-smi', '--query-gpu=power.draw', '--format=csv,noheader'], capture_output=True, text=True)
            power_str = result.stdout.strip()  # 전체 문자열을 얻음 (예: '17.09 W')
            power_draw = float(power_str.split()[0])  # 공백을 기준으로 분할 후 첫 번째 요소를 숫자로 변환
            timestamp = time.time() - start_time
            queue.put((timestamp, power_draw))
            time.sleep(interval)
    except Exception as e:
        print(f"Error in power measurement process: {e}")

if __name__ == "__main__":
    interval = 0.1  # 측정 간격 (초)

    # 데이터를 공유할 큐 생성
    queue = multiprocessing.Queue()

    # 전력 측정 프로세스 시작
    power_process = multiprocessing.Process(target=measure_power, args=(queue, interval))
    power_process.start()

    try:
        # 벤치마크 실행 (여기서는 예시로 대기)
        history = model.fit(train_images, train_labels, batch_size=512, epochs=50, validation_split = 0.2)
    except KeyboardInterrupt:
        # 사용자가 Ctrl+C로 인터럽트한 경우 프로세스 종료
        pass

    # 전력 측정 프로세스 종료
    power_process.terminate()
    power_process.join()

    # 측정된 전력 소비량 처리
    total_energy = 0.0
    total_time = 0.0

    while True:
        try:
            timestamp, power_draw = queue.get_nowait()
            if timestamp > total_time:
                total_energy += power_draw * (timestamp - total_time)
                total_time = timestamp
        except Empty:
            break

    total_power_consumption = total_energy / 3600.0  # 에너지를 시간으로 나누어 소비전력으로 변환

    print(f"Total power consumption during benchmark: {total_power_consumption:.2f} W")

    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Program Elapsed time: {elapsed_time:.2f} seconds")

