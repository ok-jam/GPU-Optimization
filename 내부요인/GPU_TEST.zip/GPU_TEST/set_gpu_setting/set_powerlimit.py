import subprocess
import os

def set_power_limit(gpu_index, new_power_limit):
    try:
        # 현재 GPU의 power limit 범위를 확인합니다.
        query_command = f'nvidia-smi -i {gpu_index} --query-gpu=power.min_limit,power.max_limit --format=csv'
        result = subprocess.run(query_command, check=True, shell=True, capture_output=True, text=True)
        print(result.stdout)
        
        # power limit을 설정합니다.
        set_command = f'nvidia-smi -i {gpu_index} -pl {new_power_limit}'
        subprocess.run(set_command, check=True, shell=True)
        print(f'Successfully set power limit of GPU {gpu_index} to {new_power_limit}W')
    except subprocess.CalledProcessError as e:
        print(f'Failed to set power limit: {e}')
    except FileNotFoundError:
        print('nvidia-smi not found. Please ensure NVIDIA drivers are installed and nvidia-smi is in your PATH.')

# 예시: 첫 번째 GPU의 power limit을 150W로 설정합니다.
set_power_limit(0, 220)
