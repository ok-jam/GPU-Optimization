import pynvml

# Initialize NVML
pynvml.nvmlInit()

# Get the number of NVIDIA GPUs
device_count = pynvml.nvmlDeviceGetCount()

for i in range(device_count):
    handle = pynvml.nvmlDeviceGetHandleByIndex(i)
    
    # Get current clock info
    clock_info = pynvml.nvmlDeviceGetClockInfo(handle, pynvml.NVML_CLOCK_GRAPHICS)
    print(f"GPU {i}: Current graphics clock: {clock_info} MHz")
    
    # Set a new clock speed (example, setting to 1500 MHz)
    new_clock_speed = 1500  # in MHz
    pynvml.nvmlDeviceSetApplicationsClocks(handle, new_clock_speed, new_clock_speed)

# Shutdown NVML
pynvml.nvmlShutdown()
