# nvidia-smi를 통해서 현재 GPU의 상태를 확인

import subprocess

def get_gpu_info():
    try:
        # Run the nvidia-smi command and capture the output
        result = subprocess.run(['nvidia-smi', '-q', '-d', 'CLOCK,POWER,TEMPERATURE,UTILIZATION'], capture_output=True, text=True, check=True)
        
        # Print the output
        print(result.stdout)
        
        # If you want to parse the output and extract specific information, you can do so
        # For simplicity, here we just return the full output
        return result.stdout
    
    except subprocess.CalledProcessError as e:
        print(f"Failed to get GPU info: {e}")
        return None

# Example usage:
gpu_info = get_gpu_info()
