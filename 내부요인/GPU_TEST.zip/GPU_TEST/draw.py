import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 데이터 준비
data = {
    'Governor': ['Default', 'Sweetspot', 'FFT'],
    'Time': [46.28, 48.33, 47.62],
    'Total Power Consumption': [1.63, 1.30, 1.47]
}

df = pd.DataFrame(data)

# 그래프 크기 설정
fig, ax1 = plt.subplots(figsize=(10, 6))

# 시간(Time)에 대한 막대 그래프 그리기 (왼쪽 축 사용)
bar_width = 0.4  # 막대의 너비
bar_positions = np.arange(len(df['Governor']))  # 첫 번째 막대의 위치
bars1 = ax1.barh(bar_positions - bar_width/2, df['Time'], height=bar_width, color='b', alpha=0.5, label='Execution Time')

# y 축 설정 (왼쪽 축)
ax1.set_yticks(bar_positions)
ax1.set_yticklabels(df['Governor'])
ax1.set_ylabel('Governor')
ax1.set_xlabel('Execution Time (s)')
ax1.set_title('Comparison of Execution Time and Power Consumption by Governor')

# 전력 소비량(Total Power Consumption)에 대한 막대 그래프 그리기 (오른쪽 축 사용)
ax2 = ax1.twiny()  # 새로운 축 생성 (오른쪽 축)
bars2 = ax2.barh(bar_positions + bar_width/2, df['Total Power Consumption'], height=bar_width, color='r', alpha=0.5, label='Power Consumption')

# x 축 설정 (오른쪽 축)
ax2.set_xlabel('Total Power Consumption (W)')

# 범례 추가
bars = bars1 + bars2
labels = [bar.get_label() for bar in bars]
ax1.legend(bars, labels, loc='best')

# 그래프 보여주기
plt.tight_layout()
plt.show()
