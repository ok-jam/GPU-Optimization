import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq
import pandas as pd

# CSV 파일에서 데이터 불러오기
df = pd.read_csv("gpu_metrics.csv", chunksize=100)

# FFT 수행
def perform_fft(data, sampling_rate=10):
    n = len(data)
    T = 1 / sampling_rate  # Sampling interval
    yf = fft(data)
    xf = fftfreq(n, T)[:n//2]
    return xf, 2.0/n * np.abs(yf[:n//2])

# FFT 결과 그리기
def plot_fft(xf, yf, label):
    plt.plot(xf, yf, label=label)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.title(f'FFT of {label}')
    plt.show()

# 데이터를 100줄씩 읽어서 FFT 수행 및 그래프 표시
for chunk in df:
    gpu_load_data = chunk['GPU Load'].to_numpy()
    memory_load_data = chunk['Memory Load'].to_numpy()
    power_usage_data = chunk['Power Usage'].to_numpy()

    xf_gpu, yf_gpu = perform_fft(gpu_load_data)
    plot_fft(xf_gpu, yf_gpu, 'GPU Load')

    xf_memory, yf_memory = perform_fft(memory_load_data)
    plot_fft(xf_memory, yf_memory, 'Memory Load')

    xf_power, yf_power = perform_fft(power_usage_data)
    plot_fft(xf_power, yf_power, 'Power Usage')
