import subprocess
import re

def get_gpu_memory_usage():
    try:
        # nvidia-smi 명령 실행
        result = subprocess.run(['nvidia-smi', '--query-gpu=memory.used,memory.total', '--format=csv,noheader,nounits'], 
                                stdout=subprocess.PIPE, 
                                encoding='utf-8')
        
        # 결과 파싱
        gpu_memory_info = result.stdout.strip().split('\n')
        memory_usages = []
        
        for gpu in gpu_memory_info:
            used_memory, total_memory = map(int, gpu.split(','))
            memory_usage_percentage = (used_memory / total_memory) * 100
            memory_usages.append(memory_usage_percentage)
        
        return memory_usages
    
    except Exception as e:
        print(f"Error: {e}")
        return None

# GPU 메모리 사용률 가져오기
gpu_memory_usage = get_gpu_memory_usage()

if gpu_memory_usage is not None:
    for idx, usage in enumerate(gpu_memory_usage):
        print(f"GPU {idx}: Memory Usage: {usage:.2f}%")
else:
    print("Failed to retrieve GPU memory usage.")
