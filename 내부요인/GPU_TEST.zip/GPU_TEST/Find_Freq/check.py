import numpy as np
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image

# 이미지 파일 경로
img_path = 'test.jpg'

# 이미지 불러오기 및 전처리
img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)

# ResNet50 모델 불러오기 (pre-trained 가중치 사용)
model = ResNet50(weights='imagenet')

# 이미지를 이용하여 예측 수행
preds = model.predict(x)

# 예측 결과 디코딩하여 인쇄
print('Predicted:', decode_predictions(preds, top=3)[0])
