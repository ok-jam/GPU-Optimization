import pandas as pd
import matplotlib.pyplot as plt

# CSV 파일에서 데이터 불러오기
csv_file = "gpu_metrics.csv"
chunk_size = 100
df_iter = pd.read_csv(csv_file, chunksize=chunk_size)

# 데이터 처리 및 그래프 그리기
for chunk in df_iter:
    # Memory Load를 100을 곱하여 %로 변환
    chunk['Memory Load'] *= 100

    # GPU Load, Memory Load, Power Usage 그래프 그리기
    plt.figure(figsize=(15, 10))

    # GPU Load 그래프
    plt.subplot(3, 1, 1)
    plt.plot(chunk.index, chunk['GPU Load'], label='GPU Load', color='blue')
    plt.xlabel('Index')
    plt.ylabel('GPU Load (%)')
    plt.title('GPU Load over Index')
    plt.ylim(0, 110)
    plt.legend()

    # Memory Load 그래프
    plt.subplot(3, 1, 2)
    plt.plot(chunk.index, chunk['Memory Load'], label='Memory Load', color='green')
    plt.xlabel('Index')
    plt.ylabel('Memory Load (%)')
    plt.title('Memory Load over Index')
    plt.ylim(0, 110)
    plt.legend()

    # Power Usage 그래프
    plt.subplot(3, 1, 3)
    plt.plot(chunk.index, chunk['Power Usage'], label='Power Usage', color='red')
    plt.xlabel('Index')
    plt.ylabel('Power Usage (%)')
    plt.title('Power Usage over Index')
    plt.ylim(0, 110)
    plt.legend()

    plt.tight_layout()
    plt.show()
