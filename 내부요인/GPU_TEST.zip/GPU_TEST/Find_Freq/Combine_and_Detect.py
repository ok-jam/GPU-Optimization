import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq
from scipy.signal import find_peaks
import pandas as pd

# CSV 파일에서 데이터 불러오기
df = pd.read_csv("gpu_metrics.csv", chunksize=100)

# FFT 수행
def perform_fft(data, sampling_rate=10):
    n = len(data)
    T = 1 / sampling_rate  # Sampling interval
    yf = fft(data)
    xf = fftfreq(n, T)[:n//2]
    return xf, 2.0/n * np.abs(yf[:n//2])

# FFT 결과 그리기
def plot_fft(xf, yf, peak_freq, period, label):
    plt.plot(xf, yf, label=label)
    if peak_freq:
        plt.axvline(x=peak_freq, color='r', linestyle='--', label=f'Peak Frequency: {peak_freq:.2f} Hz')
        plt.text(peak_freq, np.max(yf), f'Period: {period:.2f} seconds', verticalalignment='bottom', horizontalalignment='right', color='r', fontsize=10)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Amplitude')
    plt.ylim(0, 50)  # y축 범위 설정
    plt.legend()
    plt.title(f'FFT of {label}')
    plt.show()

def find_peak_frequency(xf, yf):
    peaks, _ = find_peaks(yf)
    if peaks.size > 0:
        main_peak = xf[peaks[np.argmax(yf[peaks])]]
    else:
        main_peak = None
    return main_peak


# 데이터를 100줄씩 읽어서 FFT 수행 및 그래프 표시
for chunk in df:
    gpu_load_data = chunk['GPU Load'].to_numpy()
    memory_load_data = chunk['Memory Load'].to_numpy()
    power_usage_data = chunk['Power Usage'].to_numpy()

    xf_gpu, yf_gpu = perform_fft(gpu_load_data)
    gpu_peak = find_peak_frequency(xf_gpu, yf_gpu)
    gpu_period = 1 / gpu_peak if gpu_peak else None
    #plot_fft(xf_gpu, yf_gpu, gpu_peak, gpu_period, 'GPU Load')

    xf_memory, yf_memory = perform_fft(memory_load_data)
    memory_peak = find_peak_frequency(xf_memory, yf_memory)
    memory_period = 1 / memory_peak if memory_peak else None
    #plot_fft(xf_memory, yf_memory, memory_peak, memory_period, 'Memory Load')

    xf_power, yf_power = perform_fft(power_usage_data)
    power_peak = find_peak_frequency(xf_power, yf_power)
    power_period = 1 / power_peak if power_peak else None
    #plot_fft(xf_power, yf_power, power_peak, power_period, 'Power Usage')

    # 세 개의 FFT 그래프를 단순히 더하여 합친 그래프 표시
    yf_combined = yf_gpu + yf_memory + yf_power
    xf_combined = xf_gpu  # 예시에서는 GPU Load의 주파수 범위를 사용

    combined_peak = find_peak_frequency(xf_combined, yf_combined)
    combined_period = 1 / combined_peak if combined_peak else None

    plt.figure(figsize=(12, 6))
    plt.plot(xf_combined, yf_combined, label='Combined FFT')
    if combined_peak:
        plt.axvline(x=combined_peak, color='r', linestyle='--', label=f'Peak Frequency: {combined_peak:.2f} Hz')
        plt.text(combined_peak, np.max(yf_combined), f'Period: {combined_period:.2f} seconds', verticalalignment='bottom', horizontalalignment='right', color='r', fontsize=10)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Amplitude')
    plt.ylim(0, 50)  # y축 범위 설정
    plt.legend()
    plt.title('Combined FFT of GPU Metrics')
    plt.show()
