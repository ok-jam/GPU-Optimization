import pandas as pd
import matplotlib.pyplot as plt

# CSV 파일에서 데이터 불러오기
df = pd.read_csv("gpu_metrics.csv")

# 데이터 확인
print(df.head())

# 그래프 그리기
plt.figure(figsize=(15, 8))

# GPU Load 그래프
plt.subplot(3, 1, 1)
plt.plot(df.index, df['GPU Load'], label='GPU Load', color='blue')
plt.xlabel('Time')
plt.ylabel('GPU Load (%)')
plt.title('GPU Load over Time')
plt.legend()

# Memory Load 그래프
plt.subplot(3, 1, 2)
plt.plot(df.index, df['Memory Load'], label='Memory Load', color='green')
plt.xlabel('Time')
plt.ylabel('Memory Load (%)')
plt.title('Memory Load over Time')
plt.legend()

# Power Usage 그래프
plt.subplot(3, 1, 3)
plt.plot(df.index, df['Power Usage'], label='Power Usage', color='red')
plt.xlabel('Time')
plt.ylabel('Power Usage (W)')
plt.title('Power Usage over Time')
plt.legend()

plt.tight_layout()
plt.show()
