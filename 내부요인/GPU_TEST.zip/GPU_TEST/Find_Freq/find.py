"""
# python에서 nvidia-smi를 통해서 코드의 전체 실행 기간동안 기록을 함
+ 1. GPU LOAD
+ 2. MEMORY LOAD
+ 3. POWER CONSUMPTION
+ MEMORY의 최대 사용량은 RTX3070기준으로 8196MB
+ POWER CONSUMPTION의 최대는 nvidia-smi의 power-limit을 불러와서 기준을 잡음
+ 1,2,3를 모두 %로 기록을 함
"""
"""
+ 0.1초마다 기록을 함
+ 10초마다 지금까지 기록한 데이터에 대하여 3가지 각각의 그래프에 대해서 FFT를 진행함
+ FFT를 진행한 3가지 그래프를 모두 합침
+ 합친 그래프에서 FFT의 주기를 찾아냄
"""

import subprocess
import numpy as np
import os
import csv
import seaborn as sn; sn.set(font_scale=1.4)
import matplotlib.pyplot as plt             
import cv2                                 
import tensorflow as tf                
from tqdm import tqdm
from sklearn.metrics import confusion_matrix
from sklearn.utils import shuffle   
from scipy.fft import fft, fftfreq
from scipy.signal import find_peaks
import time
import threading

# 최대 메모리 사용량과 전력 소비량 설정 (RTX 3070 기준)
MAX_MEMORY_USAGE = 8196  # MB
POWER_LIMIT_CMD = "nvidia-smi --query-gpu=power.limit --format=csv,noheader,nounits"
power_limit = float(subprocess.getoutput(POWER_LIMIT_CMD))

# 데이터 저장 리스트
gpu_loads = []
memory_loads = []
power_usages = []

def get_gpu_stats():
    smi_output = subprocess.getoutput("nvidia-smi --query-gpu=utilization.gpu,utilization.memory,power.draw --format=csv,noheader,nounits")
    gpu_load, memory_load, power_usage = map(float, smi_output.split(', '))
    gpu_load_percentage = gpu_load
    memory_load_percentage = (memory_load / MAX_MEMORY_USAGE) * 100
    power_usage_percentage = (power_usage / power_limit) * 100
    return gpu_load_percentage, memory_load_percentage, power_usage_percentage

def perform_fft(data):
    n = len(data)
    T = 0.1  # Sampling interval
    yf = fft(data)
    xf = np.fft.fftfreq(n, T)[:n//2]
    return xf, 2.0/n * np.abs(yf[:n//2])

def find_peak_frequency(xf, yf):
    peaks, _ = find_peaks(yf)
    if peaks.size > 0:
        main_peak = xf[peaks[np.argmax(yf[peaks])]]
    else:
        main_peak = None
    return main_peak

def save_to_csv(gpu_loads, memory_loads, power_usages, filename="gpu_metrics.csv"):
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        for i in range(len(gpu_loads)):
            writer.writerow([gpu_loads[i], memory_loads[i], power_usages[i]])

def collect_and_analyze_gpu_data():
    try:
        start_time = time.time()
        while True:
            # 데이터 수집
            gpu_load, memory_load, power_usage = get_gpu_stats()
            gpu_loads.append(gpu_load)
            memory_loads.append(memory_load)
            power_usages.append(power_usage)
            
            time.sleep(0.1)
            
            # 10초마다 FFT 수행
            if (time.time() - start_time) >= 10:
                start_time = time.time()

                # 데이터 저장
                save_to_csv(gpu_loads, memory_loads, power_usages)

                # GPU Load FFT
                xf, yf = perform_fft(gpu_loads)
                gpu_peak = find_peak_frequency(xf, yf)

                # Memory Load FFT
                xf, yf = perform_fft(memory_loads)
                memory_peak = find_peak_frequency(xf, yf)

                # Power Usage FFT
                xf, yf = perform_fft(power_usages)
                power_peak = find_peak_frequency(xf, yf)

                print(f"GPU Load Peak Frequency: {gpu_peak} Hz")
                print(f"Memory Load Peak Frequency: {memory_peak} Hz")
                print(f"Power Usage Peak Frequency: {power_peak} Hz")

    except KeyboardInterrupt:
        print("Data collection stopped.")

# CSV 파일에 헤더 추가
with open("gpu_metrics.csv", mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["GPU Load", "Memory Load", "Power Usage"])

# 백그라운드에서 GPU 데이터 수집 시작
gpu_thread = threading.Thread(target=collect_and_analyze_gpu_data)
gpu_thread.start()

"""
------------------------------
# 추가할 점
# nvidia-smi를 이용한 power-limit변경

+ 10초마다 GPU Load Peak Frequency, Memory Load Peak Frequency, Power Usage Peak Frequency를 
+ rtx3070의 기본 power limit은 220w
+ 첫 번째 test는 150w로 수정하고 실행
------------------------------
"""

import subprocess
import time
import multiprocessing
import cupy as cp
from queue import Empty  # queue 모듈에서 Empty 예외를 가져옵니다

def gemm_benchmark_cupy(size, num_iterations, queue=None):
    # Initialize matrices A, B, and C with random values on the GPU
    A = cp.random.rand(size, size)
    B = cp.random.rand(size, size)
    C = cp.random.rand(size, size)
    
    alpha = 1.0
    beta = 1.0
    
    # Warm-up
    cp.dot(A, B, out=C)
    cp.cuda.Stream.null.synchronize()

    # Measure performance
    start_time = time.time()
    for _ in range(num_iterations):
        C = alpha * cp.dot(A, B) + beta * C
    cp.cuda.Stream.null.synchronize()
    end_time = time.time()

    elapsed_time = end_time - start_time
    flops = 2 * size ** 3 * num_iterations  # 2 * n^3 operations per iteration
    gflops = (flops / elapsed_time) / 1e9

    print(f"Size: {size}, Time: {elapsed_time:.6f} seconds, GFLOPS: {gflops:.2f}")

    if queue:
        queue.put((elapsed_time, gflops))


gemm_benchmark_cupy(2048,2048)